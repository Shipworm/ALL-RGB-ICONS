My edit of the original Kappa Rainbow Commander mod made by a bunch of cool people.

This version uses the vanilla commander icon instead of the kappa one and adds the rainbow selection effect to all T2 and combat fabricators for improved visibility


for the original, go here:

https://forums.uberent.com/threads/rel-client-strategic-kappa-icon-commander.71368/
